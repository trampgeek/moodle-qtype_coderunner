This subtree contains the specialised adaptive quiz behaviour used by the
CodeRunner questions.

Files in this subtree (except this one) should be either copied or
symbolically linked to question/behaviour/adaptive_adapted_for_coderunner.